const ProductModel = require('../models/product');

module.exports = {
    // GET /products/all
    getAll: async (req, res) => {
        try {
            const items = await ProductModel.find({}).lean();
            res.json(items);
        } catch (error) {
            res.status(500).json({ error });
        }
    },

    // GET /products/:id
    getOne: async (req, res) => {
        try {
            const item = await ProductModel.findById(req.params.id);
            if (!item) return res.status(404).json({ message: 'product not found' });
            res.json(item);
        } catch (error) {
            res.status(500).json({ error });
        }
    },

    // POST /products
    add: async (req, res) => {
        try {
            const saved = await new ProductModel(req.body).save();
            res.status(201).json(saved);
        } catch (error) {
            res.status(500).json({ error });
        }
    },

    // PATCH /products/:id/specifications
    updateSpecifications: async (req, res) => {
        try {
            const item = await ProductModel.findByIdAndUpdate(
                req.params.id,
                { $set: { specifications: req.body.specifications } },
                { new: true }
            );
            if (!item) return res.status(404).json({ message: 'product not found' });
            res.json(item);
        } catch (error) {
            res.status(500).json({ error });
        }
    },

    // GET /products/search?title=&page=&limit=
    search: async (req, res) => {
        try {
            const { title, page = 1, limit = 10 } = req.query;
            const skip = (Number(page) - 1) * Number(limit);

            const filter = title
                ? { title: { $regex: title, $options: 'i' } }
                : {};

            const [items, total] = await Promise.all([
                ProductModel.find(filter).skip(skip).limit(Number(limit)).lean(),
                ProductModel.countDocuments(filter)
            ]);

            res.json({
                data: items,
                total,
                page: Number(page),
                limit: Number(limit),
                pages: Math.ceil(total / Number(limit))
            });
        } catch (error) {
            res.status(500).json({ error });
        }
    }
};
