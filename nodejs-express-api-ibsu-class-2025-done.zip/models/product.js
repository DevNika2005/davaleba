const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
    category: { type: String, required: true },
    title: { type: String, required: true },
    price: { type: Number, required: true },
    warehouses: [
        {
            warehouseId: { type: String, required: true },
            location: { type: String },
            quantity: { type: Number, required: true, default: 0 }
        }
    ],
    specifications: { type: mongoose.Schema.Types.Mixed, default: {} }
}, {
    collection: 'products',
    timestamps: true
});

// text index for title search
productSchema.index({ title: 'text' });

const ProductModel = mongoose.model('Product', productSchema);
module.exports = ProductModel;
