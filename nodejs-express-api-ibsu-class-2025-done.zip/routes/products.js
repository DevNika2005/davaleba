var express = require('express');
var router = express.Router();

const ProductService = require('../services/product.service');
const ApiSecurity = require('../middleware/apiSecurity');

router.get('/search', ProductService.search);
router.get('/all', ApiSecurity.requireLogin, ProductService.getAll);
router.get('/:id', ApiSecurity.requireLogin, ProductService.getOne);
router.post('/', ApiSecurity.requireLogin, ProductService.add);
router.patch('/:id/specifications', ApiSecurity.requireLogin, ProductService.updateSpecifications);

module.exports = router;
