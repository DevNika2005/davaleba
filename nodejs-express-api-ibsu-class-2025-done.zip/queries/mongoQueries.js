const mongoose = require('mongoose');

// ============================================================
// Task 1: Active users - return only name and email
// Collection schema: { _id, name, email, status, createdAt }
// ============================================================

const userSchema = new mongoose.Schema({
    name: String,
    email: String,
    status: String,
    createdAt: Date
}, { collection: 'users' });

const UserQ = mongoose.model('UserQ', userSchema);

async function getActiveUsers() {
    return UserQ.find(
        { status: 'active' },
        { name: 1, email: 1, _id: 0 }
    ).lean();
}

// ============================================================
// Task 2: Count orders by status
// Collection schema: { _id, userId, status, total }
// ============================================================

const orderSchema = new mongoose.Schema({
    userId: mongoose.Schema.Types.ObjectId,
    status: String,
    total: Number
}, { collection: 'orders' });

const OrderQ = mongoose.model('OrderQ', orderSchema);

async function countOrdersByStatus() {
    return OrderQ.aggregate([
        {
            $group: {
                _id: '$status',
                count: { $sum: 1 }
            }
        },
        { $sort: { count: -1 } }
    ]);
}

// ============================================================
// Task 3: Top 5 highest spenders (total spend per userId)
// Collection schema: { _id, userId, items: [...], totalAmount, date }
// ============================================================

const orderFullSchema = new mongoose.Schema({
    userId: mongoose.Schema.Types.ObjectId,
    items: [mongoose.Schema.Types.Mixed],
    totalAmount: Number,
    date: Date
}, { collection: 'orders' });

const OrderFull = mongoose.model('OrderFull', orderFullSchema);

async function getTop5Spenders() {
    return OrderFull.aggregate([
        {
            $group: {
                _id: '$userId',
                totalSpend: { $sum: '$totalAmount' }
            }
        },
        { $sort: { totalSpend: -1 } },
        { $limit: 5 }
    ]);
}

module.exports = { getActiveUsers, countOrdersByStatus, getTop5Spenders };
